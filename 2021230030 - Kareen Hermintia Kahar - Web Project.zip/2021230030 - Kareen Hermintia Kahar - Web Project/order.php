<?php
    require "koneksi.php";
    
    $queryOrder = mysqli_query($con, "SELECT * FROM pelanggan");
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How To Order</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>
    <!--bagian banner-->
    <div class="container-fluid banner d-flex align-item-center">
        <div class="container">
            <h1 class="text-center">Order</h1>
        </div>
    </div>
    
    <!--bagian form order-->
    <div class="cointaner-fluid py-5">
        <div class="container">
        <div class="col-12 col-md-6 mb-5">
            <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" value="" class="form-control" required>
            </div>
            <div>
                <label for="alamat">Alamat</label>
                <input type="text" id="alamat" name="alamat" value="" class="form-control" required>
            </div>
            <div>
                <label for="pesanan">Order</label>
                <input type="text" id="pesanan" name="pesanan" value="" class="form-control" required>
            </div>
            <div>
                <button type="submit" class="btn warna2 mt-3" name="simpan">Pesan</button>
            </div>
            </form>
            <?php
            if (isset($_POST['simpan'])) {
                $nama = $_POST['nama'];
                $alamat = $_POST['alamat'];
                $pesanan = $_POST['pesanan'];
                
                $queryInsert = "INSERT INTO pelanggan (nama, alamat, pesanan) VALUES ('$nama', '$alamat', '$pesanan')";
                mysqli_query($con, $queryInsert);
        
                ?>
                            <div class="alert alert-primary mt-3" role="alert">
                                Order kamu berhasil diterima!
                            </div>
                <?php
            }
            ?>
            </div>
        </div>
    </div>

      <!---footer-->
      <div class="cointaner-fluid py-3 bg-dark text-light">
            <div class="container d-flex justify-content-between">
                <label>&copy; 2023 SOCO Indonesia</label>
            </div>
        </div>
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>
