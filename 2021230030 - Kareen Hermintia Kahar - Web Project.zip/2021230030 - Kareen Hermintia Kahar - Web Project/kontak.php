<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>

    <!--bagian banner-->
    <div class="container-fluid banner d-flex align-item-center">
        <div class="container">
            <h1 class="text-center">Kontak</h1>
        </div>
    </div>
    <!--bagian kontak-->
    <div class="container-fluid pt-5 pb-5">
      <div class="container text-center">
        <div class="row pt-4 gx-4 gy-4">
          <div class="col-md-4 text-center social">
            <img src="img/ig.png" width="90" height="90" />
            <h4>Instagram</h4>
            <p>@socosoco_</p>
          </div>
          <div class="col-md-4 text-center social">
            <img src="img/tokped.png" width="90" height="90" />
            <h4>Tokopedia</h4>
            <p>socoofficial</p>
          </div>
          <div class="col-md-4 text-center social">
            <img src="img/wa.png" width="90" height="90" />
            <h4>Whatsapp</h4>
            <p>08123900020</p>
          </div>
        </div>
      </div>
    </div>

    <div class="cointaner-fluid py-3 bg-dark text-light">
        <div class="container d-flex justify-content-between">
            <label>&copy; 2023 SOCO Indonesia</label>
        </div>
    </div>


    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>