<?php
    require "koneksi.php";
    
    $nama = htmlspecialchars($_GET['nama']);
    $queryProduk = mysqli_query($con, "SELECT * FROM produk WHERE nama='$nama'");
    $produk = mysqli_fetch_array($queryProduk);

    $queryProdukTerkait = mysqli_query($con, "SELECT * FROM produk WHERE nama='$produk[nama]'");
   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk Detail</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>

    <!--detail produk-->
    <div class="container-fluid py-5">
        <div class="container text-center">
            <div class="row">
                <div class="col-md-5 mb-3">
                    <img src="img/<?php echo $produk['foto']; ?>" class="img-fluid img-thumbnail" alt="">
                </div>
                <div class="col-md-6 offset-md-1">
                    <h1><?php echo $produk['nama']; ?></h1>
                    <p class="fs-5">
                        <?php echo $produk['detail']; ?>
                    </p>
                    <p class="fs-3">
                       Rp. <?php echo $produk['harga']; ?>
                    </p>
                    <p class="fs-5">Ketersediaan: <strong><?php echo $produk['stok']; ?></strong></p>
                </div>
            </div>
        </div>
    </div>

    <!--Produk terkait-->
    <div class="container-fluid py-5 warna3">
        <div class="container">
            <h2 class="text-center mb-5">Produk Terkait</h2>
            <div class="row">
                <?php while($data = mysqli_fetch_array($queryProdukTerkait)){ ?>
                <div class="col-lg-3">
                    <a href="produk-detail.php?nama=<?php echo $data['nama']; ?>">
                    <img src="img/<?php echo $data['foto']; ?>" class="img-fluid img-thumbnail produk-terkait-image" alt="">
                    </a>
                </div>
            <?php } ?>
            </div>
        </div>
    </div>

      <!---footer-->
      <div class="cointaner-fluid py-3 bg-dark text-light">
            <div class="container d-flex justify-content-between">
                <label>&copy; 2023 SOCO Indonesia</label>
            </div>
        </div>
    
    


    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>