<?php
    require "koneksi.php";
    $queryProduk = mysqli_query($con, "SELECT id, nama, harga, foto, detail FROM produk LIMIT 3");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project UAS</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
</head>
<body>
    <?php require "navbar.php"; ?>
    <!--bagian banner-->
    <div class="container-fluid banner d-flex align-item-center">
        <div class="container text-center">
            <h1>SOCO</h1>
            <h3>Cari kebutuhan skincare?</h3>
            <form action="produk.php" method="get">
            <div class="col-md-8 offset-md-2">
            <div class="input-group input-group lg my-4">
            <input type="text" class="form-control" placeholder="Produk" aria-label="Recipient's username" aria-describedby="basic-addon2" name="keyword">
           `<button type="submit" class="btn warna2 text-white">Telusuri</button>
            </div>
            </div>
            </form>
        </div>
    </div>
    
    <!--bagian produk-->
    <div class="container-fluid py-5">
        <div class="container text-center">
            <h3>Produk</h3>
            <div class="row mt-5">
                <?php while($data = mysqli_fetch_array($queryProduk)){ ?>
                <div class="col-sm-6 col-md-4 mb-3">
                <div class="card">
                        <img src="img/<?php echo $data['foto']; ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo $data['nama']; ?></h4>
                            <p class="card-text text-truncate"><?php echo $data['detail']; ?></p>
                            <p class="card-text text-harga"><?php echo $data['harga']; ?></p>
                            <a href="produk-detail.php?nama=<?php echo $data['nama']; ?>" class="btn warna2">Lihat Detail</a>
                        </div>
                </div>
            </div>
            <?php
            }
            ?>
            </div>
            <a class="btn btn-outline-warning mt-3" href="produk.php">Lihat Produk Lainnya</a>
        </div>
    </div>

    <!-- bagian kategori -->
    <div class="container-fluid py-5">
        <div class="container text-center">
            <h3>Best Seller</h3>
            <div class="row mt-5">
                <div class="col-md-4">
                    <img src="img/sunscreen azarine.jpg" width="160" height="160"/>
                        <h4><a href="produk.php?=kategori=Sunscreen">Sunscreen Azzarine</a></h4>
                </div>
                <div class="col-md-4">
                    <img src="img/avoskin bae.jpg" width="160" height="160"/>
                        <h4><a href="produk.php?=kategori=Toner">Avoskin Bae Toner</a></h4>    
                </div>
                <div class="col-md-4">
                    <img src="img/somethinc serum.jpg" width="160" height="160"/>
                        <h4><a href="produk.php?=kategori=Serum">Somethinc Serum</a></h4>
                </div>
            </div>
        </div>
    </div>

    <!--- bagian tentang kami--->
    <div class="container-fluid py-5">
      <div class="container">
        <h3 class="text-center">Tentang Kami</h3>
        <div class="clearfix pt-5">
          <img
            src="img/about.jpg"
            class="col-md-6 float-md-end mb-3 crop-img"
            width="300"
            height="300"
          />
          <p>
            Soco adalah website skincare Indonesia yang bertujuan untuk
            memudahkan para pencari skincare untuk berbelanja kebutuhan yang
            mereka butuhkan.
          </p>
          <p>
            Dengan adanya Soco Kualitas dan keaslian produk kecantikan mirip
            dengan pentingnya merawat kulit Anda sendiri, suatu keharusan bagi
            semua wanita dan Soco menganggapnya sangat serius. Penggunaan produk
            kecantikan yang tidak asli atau palsu dapat menyebabkan kerusakan
            kulit permanen. Maka dari itu, produk yang Soco jual sudah pasti
            original, selamat berbelanja di Soco.
            <a class="btn btn-outline-warning mt-3" href="tentang_kami.php">Baca Selengkapnya</a>
          </p>
        </div>
    </div>
    
    <!---footer--->
    <?php require "footer.php"; ?>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>