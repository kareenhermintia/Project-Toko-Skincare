<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>

    <!--bagian banner-->
    <div class="container-fluid banner d-flex align-item-center">
        <div class="container">
            <h1 class="text-center">Tentang Kami</h1>
        </div>
    </div>

    <!--body tentang kami-->
    <div class="container-fluid py-5 warna4 text-light">
      <div class="container">
        <h3 class="text-center">Tentang Kami</h3>
        <div class="clearfix pt-5">
          <img
            src="img/about.jpg"
            class="col-md-6 float-md-end mb-3 crop-img"
            width="300"
            height="300"
          />
          <p>
            Soco adalah website skincare Indonesia yang bertujuan untuk
            memudahkan para pencari skincare untuk berbelanja kebutuhan yang
            mereka butuhkan.
          </p>
          <p>
            Dengan adanya Soco Kualitas dan keaslian produk kecantikan mirip
            dengan pentingnya merawat kulit Anda sendiri, suatu keharusan bagi
            semua wanita dan Soco menganggapnya sangat serius. Penggunaan produk
            kecantikan yang tidak asli atau palsu dapat menyebabkan kerusakan
            kulit permanen. Maka dari itu, produk yang Soco jual sudah pasti
            original, selamat berbelanja di Soco.
          </p>
        </div>
        <div class="clearfix pt-5">
          <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/hc8BI39g-YI"
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowfullscreen
            class="col-md-6 float-md-end mb-3"
          ></iframe>
          <h3>Kamu bingung cari skincare yang cocok?</h3>
          <p>
            Gausah khawatir, coba tonton video di sebelah kanan ini. Ada saran
            produk buat kamu nih. Yuk kita glow up bareng.
          </p>
          <p>
            Jangan lupa untuk kepoin youtube Soco ya, karena disana ada
            tips-tips tentang make up maupun skincare yang kamu butuhin lho. Yuk
            buruan subscribe supaya kamu bisa liat video baru dari Soco.
          </p>
        </div>
        <br />
        <!----bagian tabel css offline store-->
        <div class="container">
          <h3 class="text-center mb-3">Offline Store</h3>
          <table class="table-3" align="center">
            <tr>
              <th>
                  ><img src="img/offline store.jpg" width="500" height="300"/>
              </th>
              <th>
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.303149300908!2d106.8404464144933!3d-6.223700362686329!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3e54bc0d903%3A0x5582b2ccb6466e85!2sSociolla%20Store%20Kota%20Kasablanka!5e0!3m2!1sen!2sid!4v1678504234426!5m2!1sen!2sid"
                  width="500"
                  height="300"
                  style="border: 0"
                  allowfullscreen=""
                  loading="lazy"
                  referrerpolicy="no-referrer-when-downgrade"
                ></iframe>
              </th>
            </tr>
            <tr>
              <td>
                <input
                  type="submit"
                  onclick="loop()"
                  value="Klik Untuk Melihat Toko Lainnya"
                />
                <p id="demo"></p>
                <!---Bagian Looping-->
                <script>
                  function loop() {
                    const offline = [
                      "Soco Grand Indonesia",
                      "Soco Gandaria City",
                      "Soco Margo City",
                      "Soco Bintaro Exchange",
                    ];

                    let text = "";
                    for (let i = 0; i < offline.length; i++) {
                      text += offline[i] + "<br>";
                    }
                    document.getElementById("demo").innerHTML = text;
                  }
                </script>
              </td>
              <td>
                <audio controls>
                  <source src="sociola.mp3" type="audio/mp3" />
                </audio>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>

    <!---footer--->
    <div class="cointaner-fluid py-3 bg-dark text-light">
        <div class="container d-flex justify-content-between">
            <label>&copy; 2023 SOCO Indonesia</label>
        </div>
    </div>
    

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>