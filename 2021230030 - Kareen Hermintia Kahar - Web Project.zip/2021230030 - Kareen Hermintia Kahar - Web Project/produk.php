<?php
    require "koneksi.php";
    $queryKategori = mysqli_query($con, "SELECT * FROM kategori");

    //produk by search nama
    if(isset($_GET['keyword'])){
        $queryProduk = mysqli_query($con, "SELECT * FROM produk WHERE nama LIKE '%$_GET[keyword]%'");
    }
    //produk default
    else{
        $queryProduk = mysqli_query($con, "SELECT * FROM produk");
    }

    $countData = mysqli_num_rows($queryProduk);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>

    <!--bagian banner-->
    <div class="container-fluid banner d-flex align-item-center">
        <div class="container">
            <h1 class="text-center">Produk</h1>
        </div>
    </div>

    <!--produk-->
    <div class="container-fluid py-5 warna4 ">
        <div class="cointaner text-center">
        <div class="row">
            <?php 
            if($countData<1){
            ?>
                    <h3 class="text-center my-5">Tidak dapat menemukan produk</h3>
            <?php
            }
            ?>
            <div class="col-md-8 offset-md-2">
                <h3 class="text-center mb-5 text-white">Produk</h3>
                <div class="row">
                    <?php while($produk = mysqli_fetch_array($queryProduk)){ ?>
                    <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <img src="img/<?php echo $produk['foto']; ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo $produk['nama']; ?></h4>
                            <p class="card-text text-truncate"><?php echo $produk['detail']; ?></p>
                            <p class="card-text text-harga"><?php echo $produk['harga']; ?></p>
                            <a href="produk-detail.php?nama=<?php echo $produk['nama']; ?>" class="btn warna2">Lihat Detail</a>
                        </div>
                    </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    </div>
    
            <!---footer-->
        <div class="cointaner-fluid py-3 bg-dark text-light">
            <div class="container d-flex justify-content-between">
                <label>&copy; 2023 SOCO Indonesia</label>
            </div>
        </div>
         
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>