<!---bagian social media-->
<div class="container-fluid pt-5 pb-5">
      <div class="container text-center">
        <h3>Kontak</h3>
        <div class="row pt-4 gx-4 gy-4">
          <div class="col-md-4 text-center social">
            <img src="img/ig.png" width="90" height="90" />
            <h4>Instagram</h4>
            <p>@socosoco_</p>
          </div>
          <div class="col-md-4 text-center social">
            <img src="img/tokped.png" width="90" height="90" />
            <h4>Tokopedia</h4>
            <p>socoofficial</p>
          </div>
          <div class="col-md-4 text-center social">
            <img src="img/wa.png" width="90" height="90" />
            <h4>Whatsapp</h4>
            <p>08123900020</p>
          </div>
        </div>
      </div>
    </div>
    <div class="cointaner-fluid py-3 bg-dark text-light">
        <div class="container">
            <label>&copy; 2023 SOCO Indonesia</label>
        </div>
    </div>