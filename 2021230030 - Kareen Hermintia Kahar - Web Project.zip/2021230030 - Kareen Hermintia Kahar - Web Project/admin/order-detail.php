<?php
    require "session.php";
    require "../koneksi.php";

    $id = $_GET['q'];
    
    $query = mysqli_query($con, "SELECT * FROM pelanggan");
    $jumlahProduk = mysqli_num_rows($query);

    $query = mysqli_query($con, "SELECT * FROM pelanggan WHERE id='$id'");
    $data = mysqli_fetch_array($query); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Order</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<style>
    .warna1 {
        background-color: #898121;
    }

    .warna2 {
        background-color: #e7b10a;
    }

    .warna3 {
        background-color: #898121;
    }

    .warna4 {
        background-color: #862b0d;
    }
</style>
<body>
    <?php require "navbar.php"; ?>
    <div class="container mt-5">
        <h2>Order Detail</h2>
        <div class="col-12 col-md-6 mb-5">
            <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" value="<?php echo $data['nama']; ?>" class="form-control" required>
            </div>
            <div>
                <label for="alamat">Alamat</label>
                <input type="text" class="form-control" value="<?php echo $data['alamat']; ?>" name="alamat" required>
            </div>
            <div>
                <label for="pesanan">Produk</label>
                <input type="text" class="form-control" value="<?php echo $data['pesanan']; ?>" name="pesanan" required>
            </div>
            
            <div>
                <button type="submit" class="btn btn-primary mt-3" name="simpan">Update</button>
                <button type="submit" class="btn btn-danger mt-3" name="delete">Delete</button>
            </div>
            </form>
            <?php
            if (isset($_POST['simpan'])) {
                $nama = $_POST['nama'];
                $alamat = $_POST['alamat'];
                $pesanan = $_POST['pesanan'];
                
                $queryUpdate = "UPDATE pelanggan SET nama='$nama', alamat='$alamat', pesanan='$pesanan' WHERE id='$id'";
                mysqli_query($con, $queryUpdate);
        
            ?>
                        <div class="alert alert-warning mt-3" role="alert">
                                    Data sudah diupdate!
                        </div>
                        <meta http-equiv="refresh" content="1; url=order.php" />
            <?php
            }
            
            if (isset($_POST['delete'])) {
                $queryDelete = "DELETE FROM pelanggan WHERE id='$id'";
                mysqli_query($con, $queryDelete);
            ?>
                        <div class="alert alert-warning mt-3" role="alert">
                                    Data sudah dihapus!
                        </div>
                        <meta http-equiv="refresh" content="1; url=order.php" />
            <?php
            }
        ?>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>