<?php
    require "session.php";
    require "../koneksi.php";
    
    $id = $_GET['q'];

    $query = mysqli_query($con, "SELECT * FROM produk WHERE id='$id'");
    $data = mysqli_fetch_array($query); 

    function generateRandomString($length = 10){
        $characters = '0123456789abcdefghijklmnopqrstuvwzyzABCDEFGHIJKLMNOPQRSTUVWZYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++){
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<style>
    form div{
        margin-bottom: 10px;
    }
    .warna1 {
        background-color: #898121;
    }

    .warna2 {
        background-color: #e7b10a;
    }

    .warna3 {
        background-color: #898121;
    }

    .warna4 {
        background-color: #862b0d;
    }
</style>
<body>
    <?php require "navbar.php";?>
    <div class="container mt-5">
        <h2>Detail Produk</h2>
        <div class="col-12 col-md-6 mb-5">
            <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" value="<?php echo $data['nama']; ?>" class="form-control" required>
            </div>
            <div>
                <label for="harga">Harga</label>
                <input type="number" class="form-control" value="<?php echo $data['harga']; ?>" name="harga" required>
            </div>
            <div>
                <label for="currentFoto">Foto Produk</label>
                <img src="../img/<?php echo $data['foto']; ?>" alt="" width="200px">
            </div>
            <div>
                <label for="foto">Foto Produk</label>
                <input type="file" name="foto" id="foto" class="form-control">
            </div>
            <div>
                <label for="detail">Detail</label>
                <textarea name="detail" id="detail" cols="30" rows="10" class="form-control"><?php echo $data['detail']; ?></textarea>
            </div>
            <div>
                <label for="stok">Stok</label>
                <select name="stok" id="stok" class="form-control">
                    <option value="<?php echo $data['stok']; ?>"><?php echo $data['stok']; ?></option>
                    <?php
                    if($data['stok']=='tersedia'){
                ?>
                <option value="kosong">kosong</option>
        <?php
                    }
                    else {
                ?>
                    <option value="tersedia">Tersedia</option>
        <?php
                    }
        ?>
                    
                </select>
            </div>
            <div>
                <button type="submit" class="btn btn-primary" name="simpan">Update</button>
                <button type="submit" class="btn btn-danger" name="delete">Delete</button>
            </div>
            </form>
        </div>
    </div>
    
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
    if(isset($_POST['simpan'])){
        $nama = htmlspecialchars($_POST['nama']);
        $harga = htmlspecialchars($_POST['harga']);
        $detail = htmlspecialchars($_POST['detail']);
        $stok = htmlspecialchars($_POST['stok']);

        $target_dir = "../img/";
        $namafile = basename($_FILES["foto"]["name"]);
        $target_file = $target_dir . $namafile;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        $image_size = $_FILES["foto"]["size"];
        $random_name = generateRandomString(20);
        $new_name = $random_name . "." . $imageFileType;

        if($nama=='' && $harga==''){
?>
            <div class="alert alert-warning mt-3" role="alert">
                    Nama dan Harga wajib diisi!
            </div>
<?php
        }
        else{
            $queryUpdate = mysqli_query($con, "UPDATE produk SET nama='$nama', harga='$harga', detail='$detail', stok='$stok', foto='$new_name' WHERE id='$id'");

            if($queryUpdate){
                if($namafile!=''){
                    if($image_size > 500000){
?>
                        <div class="alert alert-warning mt-3" role="alert">
                            File tidak boleh dari 500kb!
                        </div>
<?php
                    }
                    else{
                        if($imageFileType != 'jpg' && $imageFileType != 'png' && $imageFileType != 'gif'){
?>
                            <div class="alert alert-warning mt-3" role="alert">
                                File wajib tipe jpg, png, gif!
                            </div>
<?php   
                        }
                        else {
                            move_uploaded_file($_FILES["foto"]["tmp_name"], $target_dir . $new_name);
?>
                            <div class="alert alert-primary mt-3" role="alert">
                                Produk Berhasil ditambahkan!
                            </div>
                            <!---untuk auto refresh halaman-->
                            <meta http-equiv="refresh" content="0; url=produk.php" />
<?php
                        }
                    }
                }
                else{
?>
                    <div class="alert alert-primary mt-3" role="alert">
                        Produk Berhasil ditambahkan!
                    </div>
                    <!---untuk auto refresh halaman-->
                    <meta http-equiv="refresh" content="0; url=produk.php" />
<?php
                }
            }
            else{
                echo mysqli_error($con);
            }
        }
    }
    
    if(isset($_POST['delete'])){
        $queryDelete = mysqli_query($con, "DELETE FROM produk WHERE id='$id'");

        if($queryDelete){
?>
            <div class="alert alert-warning mt-3" role="alert">
                Data sudah dihapus!
            </div>
            <meta http-equiv="refresh" content="1; url=produk.php" />
<?php
        }
        else{
            echo mysqli_error($con);
        }
    }
?>
