<?php
    require "session.php";
    require "../koneksi.php";

    $query = mysqli_query($con, "SELECT * FROM pelanggan");
    $jumlahProduk = mysqli_num_rows($query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
</head>
<style>
    .warna1 {
        background-color: #898121;
    }

    .warna2 {
        background-color: #e7b10a;
    }

    .warna3 {
        background-color: #898121;
    }

    .warna4 {
        background-color: #862b0d;
    }
</style>
<body>
    <?php require "navbar.php"; ?>
    <div class="container mt-5">
    <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="../admin" class="no-decoration text-muted"><i class="fas fa-home"></i> Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                     Pelanggan
                </li>
            </ol>
    </nav>
    <!--tambah pelanggan-->
    <div class="my-5 col-12 col-md-6">
        <h3>Tambah Data Pelanggan</h3>
        <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" class="form-control" required>
            </div>
            <div>
                <label for="alamat">Alamat</label>
                <input type="text" class="form-control" name="alamat" >
            </div>
            <div>
                <label for="pesanan">Produk</label>
                <input type="text" name="pesanan" id="pesanan" class="form-control">
            </div>
            <div>
                <button type="submit" class="btn warna2 mt-3" name="simpan">Simpan</button>
            </div>
        </form>
        <?php
        if(isset($_POST['simpan'])){
            $nama = htmlspecialchars($_POST['nama']);
            $alamat = htmlspecialchars($_POST['alamat']);
            $pesanan = htmlspecialchars($_POST['pesanan']);

            //query insert ke produk table
                $queryTambah  = mysqli_query($con, "INSERT INTO pelanggan (nama, alamat, pesanan) VALUES ('$nama', '$alamat', '$pesanan')");
                
                if($queryTambah){
                    ?>
                    <div class="alert alert-primary mt-3" role="alert">
                        Data Berhasil ditambahkan!
                    </div>
                    <!---untuk auto refresh halaman-->
                    <meta http-equiv="refresh" content="1; url=order.php" />
                    <?php
                }
                else {
                    echo mysqli_error($con);
                }
            }
        ?>
    </div>
    <!--membuat tabel untuk list produk database-->
    <div class="mt-3 mb-5">
            <h2>List Data Pelanggan</h2>
            <div class="table-responsive mt-5">
                <table class="table">
                <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Produk</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php
                            if($jumlahProduk==0){
                                ?>
                                <tr>
                                    <td colspan=5 class="text-center">Data Pelanggan tidak tersedia</td>
                                </tr>
                                <?php
                            }
                            else {
                                $jumlah = 1;
                                while($data=mysqli_fetch_array($query)){
                                ?>
                                <tr>
                                    <td><?php echo $jumlah; ?></td>
                                    <td><?php echo $data['nama']; ?></td>
                                    <td><?php echo $data['alamat']; ?></td>
                                    <td><?php echo $data['pesanan']; ?></td>
                                    <td>
                                    <a href="order-detail.php?q=<?php echo $data['id']; ?>" class="btn warna2">
                                    <i class="fas fa-sliders"></i></a>
                                    </td>
                                </tr>
                                <?php
                                $jumlah++;
                                }
                            }
                            ?>
                    </tbody>
                </table>
            </div>
    </div>


    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>