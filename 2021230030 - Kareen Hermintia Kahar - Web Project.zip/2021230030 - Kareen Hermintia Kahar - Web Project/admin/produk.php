<?php
    require "session.php";
    require "../koneksi.php";

    $query = mysqli_query($con, "SELECT * FROM produk");
    $jumlahProduk = mysqli_num_rows($query);

    

    function generateRandomString($length = 10){
        $characters = '0123456789abcdefghijklmnopqrstuvwzyzABCDEFGHIJKLMNOPQRSTUVWZYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++){
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
</head>
<style>
    .no-decoration {
        text-decoration: none;
    }

    form div{
        margin-bottom: 10px;
    }
    .warna1 {
        background-color: #898121;
    }

    .warna2 {
        background-color: #e7b10a;
    }

    .warna3 {
        background-color: #898121;
    }

    .warna4 {
        background-color: #862b0d;
    }
</style>
<body>
    <?php require "navbar.php";?>
    <div class="container mt-5">
    <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="../admin" class="no-decoration text-muted"><i class="fas fa-home"></i> Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                     Produk
                </li>
            </ol>
    </nav>
    <!---tambah produk-->
    <div class="my-5 col-12 col-md-6">
        <h3>Tambah Produk</h3>
        <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" class="form-control" required>
            </div>
            <div>
                <label for="harga">Harga</label>
                <input type="number" class="form-control" name="harga" >
            </div>
            <div>
                <label for="foto">Foto Produk</label>
                <input type="file" name="foto" id="foto" class="form-control">
            </div>
            <div>
                <label for="detail">Detail</label>
                <textarea name="detail" id="detail" cols="30" rows="10" class="form-control"></textarea>
            </div>
            <div>
                <label for="stok">Stok</label>
                <select name="stok" id="stok" class="form-control">
                    <option value="tersedia">Tersedia</option>
                    <option value="tersedia">Habis</option>
                </select>
            </div>
            <div>
                <button type="submit" class="btn warna2" name="simpan">Simpan</button>
            </div>
        </form>
        <?php
        if(isset($_POST['simpan'])){
            $nama = htmlspecialchars($_POST['nama']);
            $harga = htmlspecialchars($_POST['harga']);
            $detail = htmlspecialchars($_POST['detail']);
            $stok = htmlspecialchars($_POST['stok']);

            $target_dir = "../img/";
            $namafile = basename($_FILES["foto"]["name"]);
            $target_file = $target_dir . $namafile;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            $image_size = $_FILES["foto"]["size"];
            $random_name = generateRandomString(20);
            $new_name = $random_name . "." . $imageFileType;

            echo $target_dir."<br>";
            echo $namafile."<br>";
            echo $target_file."<br>";
            echo $imageFileType."<br>";
            echo $image_size."<br>";


            if($nama=='' && $harga=''){
                ?>
                    <div class="alert alert-warning mt-3" role="alert">
                        Nama dan Harga wajib diisi!
                    </div>
                <?php
            }
            else {
                if($namafile!=''){
                    if($image_size > 500000){
                    ?>
                    <div class="alert alert-warning mt-3" role="alert">
                        File tidak boleh dari 500kb!
                    </div>
                    <?php
                    }
                    else {
                        if($imageFileType != 'jpg' && $imageFileType != 'png' && $imageFileType != 'gif'){
                            ?>
                            <div class="alert alert-warning mt-3" role="alert">
                                File wajib tipe jpg, png, gif!
                            </div>
                            <?php   
                        }
                        else {
                            move_uploaded_file($_FILES["foto"]["tmp_name"], $target_dir . $new_name);
                        }
                    }
                }

                //query insert ke produk table
                $queryTambah  = mysqli_query($con, "INSERT INTO produk (id, nama, harga, foto, detail, stok) VALUES ('$kategori', '$nama', '$harga', '$new_name', '$detail', '$stok')");
                
                if($queryTambah){
                    ?>
                    <div class="alert alert-primary mt-3" role="alert">
                        Produk Berhasil ditambahkan!
                    </div>
                    <!---untuk auto refresh halaman-->
                    <meta http-equiv="refresh" content="1; url=produk.php" />
                    <?php
                }
                else {
                    echo mysqli_error($con);
                }
            }
        }
        ?>
    </div>
    <!--membuat tabel untuk list produk database-->
    <div class="mt-3 mb-5">
            <h2>List Produk</h2>
            <div class="table-responsive mt-5">
                <table class="table">
                <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php
                            if($jumlahProduk==0){
                                ?>
                                <tr>
                                    <td colspan=5 class="text-center">Data Produk tidak tersedia</td>
                                </tr>
                                <?php
                            }
                            else {
                                $jumlah = 1;
                                while($data=mysqli_fetch_array($query)){
                                ?>
                                <tr>
                                    <td><?php echo $jumlah; ?></td>
                                    <td><?php echo $data['nama']; ?></td>
                                    <td><?php echo $data['harga']; ?></td>
                                    <td><?php echo $data['stok']; ?></td>
                                    <td>
                                    <a href="produk-detail.php?q=<?php echo $data['id']; ?>" class="btn warna2">
                                    <i class="fas fa-sliders"></i></a>
                                    </td>
                                </tr>
                                <?php
                                $jumlah++;
                                }
                            }
                            ?>
                    </tbody>
                </table>
            </div>
    </div>
    
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>