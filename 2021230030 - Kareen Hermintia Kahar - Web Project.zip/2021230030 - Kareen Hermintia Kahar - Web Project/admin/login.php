<?php
    session_start();
    require "../koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<style>
    .main{
        height: 100vh;
    }
    .login-box{
        width: 500px;
        height: 300px;
        box-sizing: border-box;
        border-radius: 10px;
    }
    .warna1 {
        background-color: #898121;
    }

    .warna2 {
        background-color: #e7b10a;
    }

    .warna3 {
        background-color: #898121;
    }

    .warna4 {
        background-color: #862b0d;
    }
</style>
<body>
    <div class="main d-flex flex-column justify-content-center align-items-center">
        <div class="login-box p-5 shadow">
            <h3 class="text-center">Login Admin</h3>
            <form action="" method="post">
                <div>
                    <label for="username">Username</label>
                    <input type="text" class="form-control" name="username" id="username">
                </div>
                <div>
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password">
                </div>
                <div>
                    <button class="btn warna2 form-control mt-3" type="submit" name="loginbtn">Login</button>
                </div>
            </form>
        </div>
        <div class="mt-3" style="width: 500px">
            <?php
            if(isset($_POST['loginbtn'])){
                $username = htmlspecialchars($_POST['username']);
                $password = htmlspecialchars($_POST['password']);

                $query = mysqli_query($con,"SELECT * FROM users WHERE username='$username'");
                $countdata = mysqli_num_rows($query);
                $data = mysqli_fetch_array($query);
                
                //username : admin
                //password : hai123
                if($countdata>0){
                    if(password_verify($password, $data['password'])){
                        $_SESSION['username'] = $data['username'];
                        $_SESSION['login'] = true;
                        header('location: index.php');
                    } 
                    else {
                        ?>
                        <div class="alert alert-warning" role="alert">
                             Password salah!
                        </div>
                        <?php
                    }
                } 
                else {
                    ?>
                    <div class="alert alert-warning" role="alert">
                         Tidak dapat login, coba lagi!
                    </div>
                    <?php
                }
            }
            ?>
        </div>
    </div>
</body>
</html>