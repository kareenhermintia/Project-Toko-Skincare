-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Jul 2023 pada 06.37
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_skincare`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(2, 'Sunscreen'),
(3, 'Serum'),
(4, 'Moisturizer'),
(5, 'Toner ');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `pesanan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id`, `nama`, `alamat`, `pesanan`) VALUES
(1, 'Kareen', 'Jalan Sawo Kecik 1', 'Hale Moisturizer'),
(2, 'Kania', 'Jalan Bojong Indah ', 'Sunscreen Azzarine'),
(3, 'Anggy', 'Jalan Harapan Indah', 'Hale Moisturizer');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `harga` double NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `stok` enum('kosong','tersedia') DEFAULT 'tersedia'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id`, `nama`, `harga`, `foto`, `detail`, `stok`) VALUES
(1, 'Sunscreen Azzarine', 65000, 'WiJTzUp4E6TAfvFyvcIK.jpg', 'Melindungi kulit dari paparan sinar matahari.\r\n\r\nTipe: Sunscreen Wajah dengan spf 45+', 'tersedia'),
(2, 'Hale Moisturizer', 129000, 'ki3pri4EC2ZD9ogtltj5.jpg', 'Pelembab untuk kulit kombinasi.', 'tersedia'),
(4, 'Avoskin Retinol Toner', 175000, 'pUbphAlaZTQckH5eBgAZ.jpg', 'Membantu memicu proses regenerasi sel kulit, menyamarkan tampilan garis halus, membantu menghaluskan tekstur kulit, membantu mencerahkan kulit, merawat kulit agar tampak lebih sehat, dan membantu menyamarkan munculnya tanda-tanda penuaan dini.', 'tersedia'),
(5, 'Some By Mi Toner', 150000, 'tPdliOtQCHfRg9dmJYKD.jpg', 'Dapat menampilkan perbaikan kulit setelah 30 hari pemakaian.', 'tersedia'),
(6, 'Cosrx Cleansing Gel', 110000, 'Z1AvMZYyw7lQ5M0Hieco.jpg', 'Gel cleanser yang mampu menenangkan, mengeksfoliasi, melembapkan sekaligus membersihkan kulit wajah.', 'tersedia'),
(7, 'The Ordinary Serum', 155000, '5Tk25gjEZZjk7Ub5sSIr.jpg', 'Membantu untuk membersihkan pori-pori yang tersumbat. Selain itu, dilengkapi oleh Tasmanian Pepperberry yang dapat mengurangi iritasi karena penggunaan acid.', 'tersedia'),
(8, 'The Origanote Moisturizer', 75000, 'BCOM9RogGZCNKyRrfTCB.jpg', 'Untuk memperbaiki skin barrier, mengunci hidrasi pada kulit, menenangkan kemerahan, menjaga elastisitas kulit wajah, sebagai sumber antioksidan, dan mengontrol minyak yang berlebih.', 'tersedia'),
(9, 'Sunscreen Biore', 60000, 'zHM736BoLqZorsTGl2m1.jpg', 'Melindungi kulit dari paparan sinar matahari.                                                             ', 'tersedia'),
(11, 'Axis-Y Dark Spot Serum', 110000, '8mvoEbLtIwEoErWLCckh.jpg', 'Mampu meredakan jerawat dan bisa mengurangi noda bekas jerawat', 'tersedia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', '$1$F4a.REnh$4yQ4cyUA1Pl0hJ2yPqJ.N0');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
